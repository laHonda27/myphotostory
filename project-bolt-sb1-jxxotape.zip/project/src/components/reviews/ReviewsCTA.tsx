import ShareExperience from './ShareExperience';

export default function ReviewsCTA() {
  return <ShareExperience />;
}