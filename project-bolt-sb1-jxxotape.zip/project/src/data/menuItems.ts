export const menuItems = [
  {
    label: 'Accueil',
    path: '/'
  },
  {
    label: 'Services',
    path: '/services'
  },
  {
    label: 'Réalisations',
    path: '/realisations'
  },
  {
    label: 'Avis client',
    path: '/avis'
  },
  {
    label: 'Tarifs',
    path: '/tarifs'
  },
  {
    label: 'Contact',
    path: '/contact'
  }
];