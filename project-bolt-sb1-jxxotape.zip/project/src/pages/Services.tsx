import React from 'react';
import ServicesSection from '../components/services/ServicesSection';

export default function Services() {
  return (
    <main className="pt-20">
      <ServicesSection />
    </main>
  );
}